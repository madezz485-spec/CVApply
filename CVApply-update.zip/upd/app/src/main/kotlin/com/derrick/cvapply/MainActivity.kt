package com.derrick.cvapply

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Base64
import androidx.activity.ComponentActivity
import androidx.core.content.FileProvider
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.*

fun gemini(key: String, prompt: String, pdfB64: String): String {
    var last: Exception = Exception("No model worked")
    for (model in listOf("gemini-3.8-flash", "gemini-3.6-flash")) {
        try {
            val parts = JSONArray()
                .put(JSONObject().put("inline_data", JSONObject().put("mime_type", "application/pdf").put("data", pdfB64)))
                .put(JSONObject().put("text", prompt))
            val body = JSONObject().put("contents", JSONArray().put(JSONObject().put("parts", parts)))
            val c = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
                .openConnection() as HttpURLConnection
            c.requestMethod = "POST"; c.connectTimeout = 30000; c.readTimeout = 120000
            c.setRequestProperty("x-goog-api-key", key)
            c.setRequestProperty("Content-Type", "application/json")
            c.doOutput = true
            c.outputStream.use { it.write(body.toString().toByteArray()) }
            val ok = c.responseCode < 400
            val txt = (if (ok) c.inputStream else c.errorStream).bufferedReader().readText()
            if (!ok) throw Exception("${c.responseCode}: " + txt.take(250))
            val arr = JSONObject(txt).getJSONArray("candidates").getJSONObject(0)
                .getJSONObject("content").getJSONArray("parts")
            val sb = StringBuilder()
            for (i in 0 until arr.length()) sb.append(arr.getJSONObject(i).optString("text"))
            return sb.toString()
        } catch (e: Exception) {
            last = e
            if (e.message?.startsWith("404") != true) throw e
        }
    }
    throw last
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { Surface { App() } } }
    }
}

@Composable
fun App() {
    val ctx = LocalContext.current
    val prefs = ctx.getSharedPreferences("p", Context.MODE_PRIVATE)
    val scope = rememberCoroutineScope()
    val cvFile = File(ctx.filesDir, "cv.pdf")
    var key by remember { mutableStateOf(prefs.getString("gkey", "") ?: "") }
    var query by remember { mutableStateOf(prefs.getString("query", "") ?: "") }
    var hasCv by remember { mutableStateOf(cvFile.exists()) }
    var status by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var history by remember { mutableStateOf(prefs.getString("history", "") ?: "") }
    var company by remember { mutableStateOf("") }
    var title by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var ad by remember { mutableStateOf("") }
    var letter by remember { mutableStateOf("") }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        uri?.let {
            ctx.contentResolver.openInputStream(it)?.use { s -> cvFile.writeBytes(s.readBytes()) }
            hasCv = true
        }
    }

    fun openSearch(q: String) {
        prefs.edit().putString("query", query).apply()
        val url = "https://www.google.com/search?q=" + URLEncoder.encode(q, "UTF-8")
        ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp).statusBarsPadding(),
        verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("CV Apply", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)

        Text("1. Settings", fontWeight = FontWeight.Bold)
        OutlinedTextField(key, { key = it }, label = { Text("Gemini API key (free)") },
            visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth(), singleLine = true)
        Button(onClick = {
            prefs.edit().putString("gkey", key.trim()).apply()
            status = "Settings saved"
        }) { Text("Save settings") }
        OutlinedButton(onClick = { picker.launch("application/pdf") }) {
            Text(if (hasCv) "CV loaded - tap to replace" else "Choose your CV (PDF)")
        }

        Text("2. Find a vacancy", fontWeight = FontWeight.Bold)
        OutlinedTextField(query, { query = it }, label = { Text("Job and area, e.g. IT support Cape Town") },
            modifier = Modifier.fillMaxWidth())
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(enabled = query.isNotBlank(), onClick = { openSearch("$query jobs") }) { Text("Google Jobs") }
            Button(enabled = query.isNotBlank(), onClick = { openSearch("site:pnet.co.za $query") }) { Text("PNet") }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(enabled = query.isNotBlank(), onClick = { openSearch("site:indeed.co.za $query") }) { Text("Indeed") }
            Button(enabled = query.isNotBlank(), onClick = { openSearch("site:careers24.com $query") }) { Text("Careers24") }
        }

        Text("3. Enter the vacancy details", fontWeight = FontWeight.Bold)
        OutlinedTextField(title, { title = it }, label = { Text("Job title") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        OutlinedTextField(company, { company = it }, label = { Text("Company") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        OutlinedTextField(email, { email = it }, label = { Text("Email to apply to") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        OutlinedTextField(ad, { ad = it }, label = { Text("Paste the job ad (optional)") },
            modifier = Modifier.fillMaxWidth(), minLines = 3)

        Button(enabled = !busy && hasCv && key.isNotBlank() && title.isNotBlank() && company.isNotBlank(), onClick = {
            scope.launch {
                busy = true; status = "Writing cover letter..."
                try {
                    val cv = Base64.encodeToString(cvFile.readBytes(), Base64.NO_WRAP)
                    val prompt = "Read the attached CV. Write a short, honest cover letter (under 180 words, plain text) " +
                        "applying for '$title' at $company. Use only facts that appear in the CV; do not invent " +
                        "skills, dates or qualifications. " +
                        (if (ad.isNotBlank()) "Job ad:\n$ad\n" else "") +
                        "Start with 'Dear Hiring Manager,' and end with the candidate's name from the CV. Output only the letter."
                    letter = withContext(Dispatchers.IO) { gemini(key, prompt, cv) }.trim()
                    status = "Check the letter, edit if needed, then open Gmail."
                } catch (e: Exception) {
                    status = "Error: ${e.message}"
                }
                busy = false
            }
        }) { Text(if (busy) "Working..." else "Write cover letter") }

        if (status.isNotEmpty()) Text(status)

        if (letter.isNotEmpty()) {
            OutlinedTextField(letter, { letter = it }, label = { Text("Cover letter (editable)") },
                modifier = Modifier.fillMaxWidth(), minLines = 6)
            Button(enabled = email.isNotBlank(), onClick = {
                try {
                    val f = File(ctx.cacheDir, "CV.pdf"); cvFile.copyTo(f, overwrite = true)
                    val uri = FileProvider.getUriForFile(ctx, "com.derrick.cvapply.fileprovider", f)
                    val send = Intent(Intent.ACTION_SEND).apply {
                        type = "application/pdf"
                        putExtra(Intent.EXTRA_EMAIL, arrayOf(email.trim()))
                        putExtra(Intent.EXTRA_SUBJECT, "Application: $title")
                        putExtra(Intent.EXTRA_TEXT, letter)
                        putExtra(Intent.EXTRA_STREAM, uri)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    try { ctx.startActivity(Intent(send).setPackage("com.google.android.gm")) }
                    catch (e: Exception) { ctx.startActivity(Intent.createChooser(send, "Send with")) }
                    val line = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date()) +
                        " | $title | $company | $email"
                    history = line + "\n" + history
                    prefs.edit().putString("history", history).apply()
                } catch (e: Exception) { status = "Could not open email: ${e.message}" }
            }) { Text("Open Gmail with CV") }
            if (email.isBlank()) Text("Enter the email address above first.")
        }

        if (history.isNotBlank()) {
            Text("History", fontWeight = FontWeight.Bold)
            Text(history)
        }
        Spacer(Modifier.height(24.dp))
    }
}
