package com.derrick.cvapply

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Base64
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.*
import javax.activation.DataHandler
import javax.mail.*
import javax.mail.internet.*
import javax.mail.util.ByteArrayDataSource

data class Vacancy(val title: String, val company: String, val email: String, val url: String,
                   val summary: String, val letter: String = "", val sent: Boolean = false)

fun claude(key: String, prompt: String, pdfB64: String?, search: Boolean): String {
    val content = JSONArray()
    if (pdfB64 != null) content.put(JSONObject().put("type", "document").put("source",
        JSONObject().put("type", "base64").put("media_type", "application/pdf").put("data", pdfB64)))
    content.put(JSONObject().put("type", "text").put("text", prompt))
    val body = JSONObject().put("model", "claude-sonnet-4-6").put("max_tokens", 4000)
        .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", content)))
    if (search) body.put("tools", JSONArray().put(JSONObject().put("type", "web_search_20250305")
        .put("name", "web_search").put("max_uses", 5)))
    val c = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
    c.requestMethod = "POST"; c.connectTimeout = 30000; c.readTimeout = 180000
    c.setRequestProperty("x-api-key", key)
    c.setRequestProperty("anthropic-version", "2023-06-01")
    c.setRequestProperty("content-type", "application/json")
    c.doOutput = true
    c.outputStream.use { it.write(body.toString().toByteArray()) }
    val ok = c.responseCode < 400
    val txt = (if (ok) c.inputStream else c.errorStream).bufferedReader().readText()
    if (!ok) throw Exception(txt.take(300))
    val arr = JSONObject(txt).getJSONArray("content")
    val sb = StringBuilder()
    for (i in 0 until arr.length()) {
        val b = arr.getJSONObject(i)
        if (b.getString("type") == "text") sb.append(b.getString("text"))
    }
    return sb.toString()
}

fun sendMail(from: String, pass: String, to: String, subject: String, text: String, cv: ByteArray) {
    val props = Properties().apply {
        put("mail.smtp.auth", "true"); put("mail.smtp.starttls.enable", "true")
        put("mail.smtp.host", "smtp.gmail.com"); put("mail.smtp.port", "587")
    }
    val session = Session.getInstance(props, object : Authenticator() {
        override fun getPasswordAuthentication() = PasswordAuthentication(from, pass)
    })
    val mp = MimeMultipart()
    mp.addBodyPart(MimeBodyPart().apply { setText(text) })
    mp.addBodyPart(MimeBodyPart().apply {
        dataHandler = DataHandler(ByteArrayDataSource(cv, "application/pdf"))
        setFileName("CV.pdf")
    })
    val msg = MimeMessage(session).apply {
        setFrom(InternetAddress(from))
        setRecipients(Message.RecipientType.TO, InternetAddress.parse(to))
        setSubject(subject)
        setContent(mp)
    }
    Transport.send(msg)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { Surface { App() } } }
    }
}

@Composable
fun App() {
    val ctx = LocalContext.current
    val prefs = ctx.getSharedPreferences("p", Context.MODE_PRIVATE)
    val scope = rememberCoroutineScope()
    val cvFile = File(ctx.filesDir, "cv.pdf")
    var key by remember { mutableStateOf(prefs.getString("key", "") ?: "") }
    var gmail by remember { mutableStateOf(prefs.getString("gmail", "") ?: "") }
    var gpass by remember { mutableStateOf(prefs.getString("gpass", "") ?: "") }
    var query by remember { mutableStateOf(prefs.getString("query", "") ?: "") }
    var hasCv by remember { mutableStateOf(cvFile.exists()) }
    var status by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var history by remember { mutableStateOf(prefs.getString("history", "") ?: "") }
    val jobs = remember { mutableStateListOf<Vacancy>() }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        uri?.let {
            ctx.contentResolver.openInputStream(it)?.use { s -> cvFile.writeBytes(s.readBytes()) }
            hasCv = true
        }
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp).statusBarsPadding(),
        verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("CV Apply", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)

        Text("Settings", fontWeight = FontWeight.Bold)
        OutlinedTextField(key, { key = it }, label = { Text("Anthropic API key") },
            visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth(), singleLine = true)
        OutlinedTextField(gmail, { gmail = it }, label = { Text("Your Gmail address") },
            modifier = Modifier.fillMaxWidth(), singleLine = true)
        OutlinedTextField(gpass, { gpass = it }, label = { Text("Gmail app password (16 letters)") },
            visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth(), singleLine = true)
        Button(onClick = {
            prefs.edit().putString("key", key.trim()).putString("gmail", gmail.trim())
                .putString("gpass", gpass.replace(" ", "")).apply()
            status = "Settings saved"
        }) { Text("Save settings") }

        Text("Your CV (PDF)", fontWeight = FontWeight.Bold)
        OutlinedButton(onClick = { picker.launch("application/pdf") }) {
            Text(if (hasCv) "CV loaded - tap to replace" else "Choose CV (PDF)")
        }

        Text("Job to look for", fontWeight = FontWeight.Bold)
        OutlinedTextField(query, { query = it }, label = { Text("e.g. admin clerk, Gauteng") },
            modifier = Modifier.fillMaxWidth())
        Button(enabled = !busy && hasCv && key.isNotBlank() && query.isNotBlank(), onClick = {
            prefs.edit().putString("query", query).apply()
            scope.launch {
                busy = true; jobs.clear()
                try {
                    status = "Searching the web..."
                    val cv = Base64.encodeToString(cvFile.readBytes(), Base64.NO_WRAP)
                    val out = withContext(Dispatchers.IO) {
                        claude(key, "Read the attached CV. Search the web for current vacancies matching: $query. " +
                            "Only include vacancies that give an email address to send applications to. " +
                            "Reply with ONLY a JSON array (no markdown) of up to 5 objects with keys: " +
                            "title, company, email, url, summary (one sentence).", cv, true)
                    }
                    val arr = JSONArray(out.substring(out.indexOf('['), out.lastIndexOf(']') + 1))
                    for (i in 0 until arr.length()) {
                        val o = arr.getJSONObject(i)
                        jobs.add(Vacancy(o.optString("title"), o.optString("company"), o.optString("email"),
                            o.optString("url"), o.optString("summary")))
                    }
                    if (jobs.isEmpty()) status = "No vacancies with an email address found. Try a wider search."
                    for (i in jobs.indices) {
                        status = "Writing cover letter ${i + 1} of ${jobs.size}..."
                        val j = jobs[i]
                        val letter = withContext(Dispatchers.IO) {
                            claude(key, "Using the attached CV, write a short, honest cover letter (under 180 words, " +
                                "plain text, no placeholders) applying for '${j.title}' at ${j.company}. " +
                                "Job summary: ${j.summary}. Start with 'Dear Hiring Manager,' and end with the " +
                                "candidate's name from the CV. Output only the letter.", cv, false)
                        }
                        jobs[i] = j.copy(letter = letter.trim())
                    }
                    if (jobs.isNotEmpty()) status = "Review each one, then tap Approve & send."
                } catch (e: Exception) {
                    status = "Error: ${e.message}"
                }
                busy = false
            }
        }) { Text(if (busy) "Working..." else "Search vacancies") }

        if (status.isNotEmpty()) Text(status)

        jobs.forEachIndexed { i, j ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(j.title, fontWeight = FontWeight.Bold)
                    Text("${j.company}  |  ${j.email}")
                    Text(j.summary)
                    OutlinedTextField(j.letter, { jobs[i] = j.copy(letter = it) },
                        label = { Text("Cover letter (editable)") }, modifier = Modifier.fillMaxWidth())
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(enabled = !j.sent && !busy && j.letter.isNotBlank() && gmail.isNotBlank() && gpass.isNotBlank(),
                            onClick = {
                                scope.launch {
                                    busy = true; status = "Sending to ${j.company}..."
                                    try {
                                        withContext(Dispatchers.IO) {
                                            sendMail(gmail.trim(), gpass.replace(" ", ""), j.email.trim(),
                                                "Application: ${j.title}", j.letter, cvFile.readBytes())
                                        }
                                        jobs[i] = jobs[i].copy(sent = true)
                                        val line = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date()) +
                                            " | ${j.title} | ${j.company} | ${j.email}"
                                        history = line + "\n" + history
                                        prefs.edit().putString("history", history).apply()
                                        status = "Sent to ${j.company}"
                                    } catch (e: Exception) { status = "Send failed: ${e.message}" }
                                    busy = false
                                }
                            }) { Text(if (j.sent) "Sent" else "Approve & send") }
                        if (j.url.isNotBlank()) OutlinedButton(onClick = {
                            ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(j.url)))
                        }) { Text("Open page") }
                    }
                }
            }
        }

        if (history.isNotBlank()) {
            Text("Sent history", fontWeight = FontWeight.Bold)
            Text(history)
        }
        Spacer(Modifier.height(24.dp))
    }
}
